<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Map with Drawing Manager and Autocomplete</title>
  <!-- Include the Google Maps API script with libraries=drawing and places -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAfmkPiCdo3XIczWJ3e6kTrPPfAMCR5Vsk&libraries=drawing,places"></script>
  <!-- Include your script file -->
  <script src="script.js"></script>
</head>
<body>
  <!-- Map container -->
  <div id="map" style="height: 400px;"></div>
  
  <!-- Address autocomplete input field -->
  <input id="autocomplete" placeholder="Enter your address" type="text"></input>

  <!-- Hidden input for latitude -->
  <input type="hidden" id="latitude" value="37.7749">

<!-- Hidden input for latitude -->
  <input type="hidden" id="longitude" name="longitude">

  <!-- Other HTML elements as needed -->

  <!-- Optional: Add a button to trigger the deletion of the selected shape -->
  <button id="borrar">Delete Selected Shape</button>

  <!-- Display the computed area -->
  <div>Area: <span id="value-1">0</span></div>

  <!-- Hidden input to store the area value -->
  <input type="hidden" id="hidden-value-1" name="hidden-value-1">

  <!-- Call the initMap function when the page loads -->
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      initMap();
    });
  </script>
</body>
</html>

