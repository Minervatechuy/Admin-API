jQuery(document).ready(function($){
	
	var Ermua = new google.maps.LatLng(43.186188, -2.5113274);
	var Navarra = new google.maps.LatLng(42.7419575, -1.6284645);
	var Madrid = new google.maps.LatLng(40.4199047, -3.6661189);
    
	var latitudInstalacion = jQuery("#latitud").val();
	var longitudInstalacion = jQuery("#longitud").val();
	var Instalacion = new google.maps.LatLng(latitudInstalacion, longitudInstalacion);
	
	var hastaErmua = parseInt(((google.maps.geometry.spherical.computeDistanceBetween(Instalacion, Ermua))/1000).toFixed(2));
	var hastaNavarra = parseInt(((google.maps.geometry.spherical.computeDistanceBetween(Instalacion, Navarra))/1000).toFixed(2));
	var hastaMadrid = parseInt(((google.maps.geometry.spherical.computeDistanceBetween(Instalacion, Madrid))/1000).toFixed(2));
	if ( hastaErmua < hastaNavarra && hastaErmua < hastaMadrid ) {
		jQuery("#distancia").val(hastaErmua);
		jQuery("#sedeMasCercana").val("Ermua");
		//alert("hastaErmua");
	}
	if ( hastaNavarra < hastaErmua && hastaNavarra < hastaMadrid ) {
		jQuery("#distancia").val(hastaNavarra);
		jQuery("#sedeMasCercana").val("Navarra");
		//alert("hastaNavarra");
	}
	if ( hastaMadrid < hastaNavarra && hastaMadrid < hastaErmua ) {
		jQuery("#distancia").val(hastaMadrid);
		jQuery("#sedeMasCercana").val("Madrid");
		//alert("hastaMadrid");
	}
	
});